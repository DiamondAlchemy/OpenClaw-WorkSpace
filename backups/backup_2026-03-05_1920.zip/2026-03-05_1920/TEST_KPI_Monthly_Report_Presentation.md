# MONTHLY CLIENT REPORT

**Client:** Test KPI for PiP Operations  
**Reporting Period:** February 2026  
**Generated:** March 5, 2026  
**Prepared by:** Top Secret Workshop

---

## EXECUTIVE SUMMARY

February 2026 marked a strong operational month with 19 extraction runs completed across Fresh Frozen and Cured material types. The facility processed 1,055 lbs of biomass and produced 33,868 g of finished product. Post-processing efficiency remained high at 96.2%, with 4 batches (4,568 g) remaining in process.

**Key Highlights:**
- 19 runs completed across 9 active production days
- Cured yield at 12.41% significantly outperforming Fresh Frozen at 3.75%
- Post-processing efficiency maintained at 96.2%
- Strong product mix diversity across Badder, Sauce, Isolation, Sugar, and Shatter

---

## FRESH FROZEN

### Production Metrics
| Metric | Value |
|--------|-------|
| Extraction Runs | 9 |
| Biomass Processed | 650 lbs |
| Finished Output | 11,068 g |
| Average Yield | 3.75% |
| Post Processing Efficiency | 95.4% |
| Average Residual Loss | 88.3 g |

### Production Mix
| Process Type | Runs | Output (g) |
|--------------|------|------------|
| Badder | 3 | 4,280 |
| Sauce | 1 | 2,750 |
| Isolation | 1 | 2,712 |
| Sugar | 1 | 1,326 |

---

## CURED

### Production Metrics
| Metric | Value |
|--------|-------|
| Extraction Runs | 10 |
| Biomass Processed | 405 lbs |
| Finished Output | 22,800 g |
| Average Yield | 12.41% |
| Post Processing Efficiency | 96.9% |
| Average Residual Loss | 103.4 g |

### Work In Progress
| Status | Count | Weight |
|--------|-------|--------|
| Batches Pending | 3 | 3,697 g |

### Production Mix
| Process Type | Runs | Output (g) |
|--------------|------|------------|
| Isolation | 5 | 12,779 |
| Sugar | 1 | 2,521 |
| Shatter | 1 | 7,500 |

---

## CONSUMABLES (Combined)

| Consumable | Usage |
|------------|-------|
| T5 | 13,725 g |
| CRY | 18,900 g |
| Silica | 15,885 g |
| Butane Loss | 639 lbs |
| Nitrogen Cylinders | 8 |

---

## OPERATIONAL AVAILABILITY

| Metric | Value |
|--------|-------|
| Active Production Days | 9 |
| Total Runs | 19 |
| Runs per Active Day | 2.1 |
| Biomass per Day | 117 lbs |
| Finished Output per Day | 3,763 g |

---

## NEXT MONTH FOCUS

1. **Butane Recovery:** Increase recovery speed to improve throughput
2. **Shatter Quality:** Reduce sugaring on shatter runs for better product consistency
3. **Throughput:** Increase overall production capacity by 25%
4. **Diamond Consistency:** Refine diamond size parameters for improved consistency across batches

---

## EXTERNAL CONTEXT

Yield analysis by farm recommended to identify lowest-performing sources. This analysis will inform vendor selection and biomass sourcing decisions for the coming month.

---

## NOTES

- Fresh Frozen and Cured yields calculated separately per client specification
- Yield formula: (output grams / input grams) x 100
- WIP batches excluded from finished output totals
- Data source: Fresh Frozen, Cured, and Post Extraction tabs (KPI tracker)

---

*Report prepared by Top Secret Workshop*
