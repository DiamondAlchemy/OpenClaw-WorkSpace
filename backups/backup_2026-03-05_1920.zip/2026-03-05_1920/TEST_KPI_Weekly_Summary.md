# WEEKLY INTERNAL SUMMARY

**Client:** Test KPI for PiP Operations  
**Reporting Period:** February 2026 (Partial Month)  
**Generated:** March 5, 2026  
**Prepared by:** Top Secret Workshop

---

## PRODUCTION METRICS

| Metric | Value |
|--------|-------|
| Total Extraction Runs | 20 |
| Fresh Frozen Runs | 9 |
| Cured Runs | 11 |
| Total Biomass Processed | 1,075 lbs |
| Fresh Frozen | 650 lbs |
| Cured | 425 lbs |

---

## YIELD METRICS

| Metric | Fresh Frozen | Cured | Combined |
|--------|-------------|-------|----------|
| Total Finished Output | 11,068 g | 22,800 g | 33,868 g |
| Average Yield | 4.07% | 12.41% | 6.95% |

---

## POST PROCESSING METRICS

| Metric | Value |
|--------|-------|
| Total Pre-Process Weight | 35,122 g |
| Total Post Purge Weight | 33,868 g |
| Average Residual/Loss | 96.5 g |
| Post Processing Efficiency | 96.4% |

---

## CONSUMABLE METRICS

| Consumable | Usage |
|------------|-------|
| T5 (Fresh Frozen) | 13,725 g |
| CRY (Cured) | 18,900 g |
| Silica (Combined) | 15,885 g |
| Butane Loss | 639 lbs |
| Nitrogen Cylinders | 8 |

---

## PRODUCTION MIX

| Process Type | Runs | Output (g) |
|--------------|------|------------|
| Isolation | 6 | 15,491 |
| Sugar | 2 | 3,847 |
| Badder | 3 | 4,280 |
| Sauce | 1 | 2,750 |
| Shatter | 1 | 7,500 |

---

## OPERATIONAL AVAILABILITY

| Metric | Value |
|--------|-------|
| Active Production Days | 9 |
| Runs per Active Day | 2.2 |
| Biomass per Day | 119.4 lbs |
| Finished Output per Day | 3,763 g |

---

## WORK IN PROGRESS

| Status | Count | Weight |
|--------|-------|--------|
| Batches In Process | 4 | 4,568 g |

**Note:** Some batches remain in post-processing and are excluded from finished output totals.

---

## NOTES

- Data extracted from Fresh Frozen, Cured, and Post Extraction tabs
- Yield calculated as: (output grams / input grams in grams) x 100
- Conversion: 1 lb = 453.592 g

---

*Report generated from KPI tracker data. Dashboard totals were not used for calculations.*
