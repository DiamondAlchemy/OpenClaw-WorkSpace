# MONTHLY CLIENT REPORT

**Client:** Test KPI for PiP Operations  
**Reporting Period:** February 2026  
**Generated:** March 5, 2026  
**Prepared by:** Top Secret Workshop

---

## EXECUTIVE SUMMARY

February 2026 marked a strong operational month with 19 extraction runs completed across Fresh Frozen and Cured material types. The facility processed 1,055 lbs of biomass and produced 33,868 g of finished product. Post-processing efficiency remained high at 96.2%, indicating robust workflow stability.

**Key Highlights:**

- 19 extraction runs completed across 9 active production days
- Cured material yielded exceptionally well at 12.41%, significantly exceeding Fresh Frozen yields of 3.75%
- Post-processing efficiency maintained at 96.2% with minimal residual loss
- 4 batches totaling 4,568 g remain in process as of month-end

---

## KPI SCORECARD

### Fresh Frozen

| Metric | Current Month |
|--------|---------------|
| Extraction Runs | 9 |
| Biomass Processed | 650 lbs |
| Finished Output | 11,068 g |
| Average Yield | 3.75% |
| Post Processing Efficiency | 95.4% |
| Active Production Days | 9 |
| Runs per Active Day | 1.0 |

### Cured

| Metric | Current Month |
|--------|---------------|
| Extraction Runs | 10 |
| Biomass Processed | 405 lbs |
| Finished Output | 22,800 g |
| Average Yield | 12.41% |
| Post Processing Efficiency | 96.9% |
| Active Production Days | 9 |
| Runs per Active Day | 1.1 |

### Comparison (Previous Month)

*No data available for comparison.*

---

## OPERATIONAL PERFORMANCE

### Throughput and Production Mix

The facility maintained a steady throughput of approximately 2.1 runs per active production day. Fresh Frozen material dominated production volume at 650 lbs (62% of total biomass), while Cured material contributed 405 lbs (38%).

**Production Mix by Process Type:**

| Process | Type | Runs | Output (g) |
|---------|------|------|------------|
| Isolation | Cured | 5 | 12,779 |
| Badder | Fresh Frozen | 3 | 4,280 |
| Sugar | Mixed | 2 | 3,847 |
| Sauce | Fresh Frozen | 1 | 2,750 |
| Shatter | Cured | 1 | 7,500 |

### Yield Efficiency

Cured material demonstrated superior yield performance at 12.41%, reflecting strong post-processing outcomes. Fresh Frozen yields of 3.75% indicate opportunity for optimization, potentially through cultivar selection or processing parameter refinement.

### Post Processing Performance

Post-processing efficiency averaged 96.2% across all batches, with average residual loss of 96.5 g per batch. This indicates consistent purging performance and stable operational procedures.

### Consumable Usage Trends

| Consumable | Usage |
|------------|-------|
| T5 | 13,725 g |
| CRY | 18,900 g |
| Silica | 15,885 g |
| Butane Loss | 639 lbs |
| Nitrogen Cylinders | 8 |

---

## OPERATIONAL INTERVENTIONS

*No interventions reported for February 2026.*

---

## NEXT MONTH FOCUS

1. **Butane Recovery:** Increase recovery speed to improve throughput
2. **Shatter Quality:** Reduce sugaring on shatter runs for better product consistency
3. **Throughput:** Increase overall production capacity by 25%
4. **Diamond Consistency:** Refine diamond size parameters for improved consistency across batches

---

## EXTERNAL CONTEXT

**Yield Analysis by Farm:** A comprehensive review of cultivar and farm performance is recommended to identify lowest-performing sources. This analysis will inform vendor selection and biomass sourcing decisions for the coming month.

---

## WORK IN PROGRESS

| Status | Count | Weight |
|--------|-------|--------|
| Batches in Post-Processing | 4 | 4,568 g |

*Note: These batches are excluded from finished output totals.*

---

## NOTES

- All yields calculated from KPI tracker data
- Fresh Frozen and Cured yields reported separately per client specification
- WIP batches excluded from finalized metrics

---

*Report prepared by Top Secret Workshop*
*Data Source: KPI Tracker (Fresh Frozen, Cured, Post Extraction tabs)*
