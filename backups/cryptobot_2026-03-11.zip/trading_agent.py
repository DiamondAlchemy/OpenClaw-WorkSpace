#!/usr/bin/env python3
"""
CryptoStrategist Agent Interface
This is what the agent uses to interact with the trading system
"""
import sys
import os
sys.path.append('/Users/m/.openclaw/workspace-cryptobot')

from strategies import create_strategy, backtest
from portfolio_manager import Portfolio, RiskManager
from exchange_client import load_historical_data
from strategy_evaluator import evaluate_strategies
import json

class TradingAgent:
    def __init__(self):
        self.portfolio = Portfolio.load()
        self.risk_manager = RiskManager()
        self.current_strategy = None
        
    def analyze_market(self, symbol='BTC', timeframe='1h'):
        """Analyze market and generate insights"""
        data = load_historical_data(symbol, timeframe)
        if data is None:
            return "No data available"
        
        # Get latest prices
        latest = data.iloc[-1]
        
        # Run quick strategy evaluation
        results = evaluate_strategies(symbol, timeframe, capital=1000)
        
        if results:
            return {
                'symbol': symbol,
                'price': float(latest['close']),
                'top_strategy': results[0]['name'],
                'expected_return': f"{results[0]['return_pct']:.2f}%",
                'portfolio_value': self.portfolio.get_equity({symbol: latest['close']})
            }
        return "Analysis complete but no results"
    
    def execute_trade(self, symbol, side, amount):
        """Execute a trade"""
        data = load_historical_data(symbol, '1h')
        if data is None:
            return "No data available"
        
        current_price = float(data.iloc[-1]['close'])
        
        if side == 'buy':
            result = self.portfolio.buy(symbol, current_price)
            self.portfolio.save()
            return f"Bought {symbol} at ${current_price}"
        elif side == 'sell':
            result = self.portfolio.sell(symbol, current_price)
            self.portfolio.save()
            return f"Sold {symbol} at ${current_price}"
        
        return "Trade failed"
    
    def run_strategy_tournament(self, symbols=['BTC', 'ETH']):
        """Run tournament to find best strategy"""
        return evaluate_strategies(symbols[0])
    
    def get_portfolio_status(self):
        """Get current portfolio status"""
        return self.portfolio.get_stats()
    
    def reset_portfolio(self):
        """Reset portfolio to initial state"""
        self.portfolio = Portfolio()
        self.portfolio.save()
        return "Portfolio reset"

# CLI for testing
if __name__ == '__main__':
    agent = TradingAgent()
    
    print("=" * 50)
    print("CRYPTOSTRATEGIST v1.0")
    print("=" * 50)
    print("\nAvailable commands:")
    print("  analyze <symbol>  - Analyze market")
    print("  buy <symbol>      - Execute buy")
    print("  sell <symbol>     - Execute sell") 
    print("  tournament        - Run strategy tournament")
    print("  status            - Portfolio status")
    print("  reset             - Reset portfolio")
    print("  quit              - Exit")
    print()
    
    while True:
        cmd = input("> ").strip().split()
        if not cmd:
            continue
            
        if cmd[0] == 'analyze':
            symbol = cmd[1] if len(cmd) > 1 else 'BTC'
            result = agent.analyze_market(symbol)
            print(result)
        elif cmd[0] == 'buy':
            symbol = cmd[1] if len(cmd) > 1 else 'BTC'
            print(agent.execute_trade(symbol, 'buy', 0.1))
        elif cmd[0] == 'sell':
            symbol = cmd[1] if len(cmd) > 1 else 'BTC'
            print(agent.execute_trade(symbol, 'sell', 0.1))
        elif cmd[0] == 'tournament':
            agent.run_strategy_tournament()
        elif cmd[0] == 'status':
            print(agent.get_portfolio_status())
        elif cmd[0] == 'reset':
            print(agent.reset_portfolio())
        elif cmd[0] in ['quit', 'exit']:
            break
