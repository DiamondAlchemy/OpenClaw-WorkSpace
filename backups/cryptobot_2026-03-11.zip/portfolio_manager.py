#!/usr/bin/env python3
"""
Portfolio Manager - Risk Management & Position Sizing
"""
import json
import os
from datetime import datetime

PORTFOLIO_FILE = '/Users/m/.openclaw/workspace-cryptobot/portfolio.json'

class Portfolio:
    def __init__(self, initial_capital=10000):
        self.initial_capital = initial_capital
        self.cash = initial_capital
        self.positions = {}  # {symbol: {'amount': x, 'entry_price': y}}
        self.trade_history = []
        self.equity_curve = []
        
    def to_dict(self):
        return {
            'initial_capital': self.initial_capital,
            'cash': self.cash,
            'positions': self.positions,
            'trade_history': self.trade_history,
            'equity_curve': self.equity_curve
        }
    
    @classmethod
    def from_dict(cls, data):
        p = cls(data.get('initial_capital', 10000))
        p.cash = data.get('cash', p.initial_capital)
        p.positions = data.get('positions', {})
        p.trade_history = data.get('trade_history', [])
        p.equity_curve = data.get('equity_curve', [])
        return p
    
    def save(self):
        with open(PORTFOLIO_FILE, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    @classmethod
    def load(cls):
        if os.path.exists(PORTFOLIO_FILE):
            with open(PORTFOLIO_FILE, 'r') as f:
                return cls.from_dict(json.load(f))
        return cls()
    
    def get_equity(self, current_prices):
        """Calculate current equity"""
        positions_value = sum(
            pos['amount'] * current_prices.get(sym, pos['entry_price'])
            for sym, pos in self.positions.items()
        )
        return self.cash + positions_value
    
    def can_buy(self, symbol, price, position_pct=0.1):
        """Check if we can buy"""
        max_position = self.cash * position_pct
        return max_position >= price * 0.001  # Min order
    
    def buy(self, symbol, price, position_pct=0.1):
        """Execute buy"""
        if not self.can_buy(symbol, price, position_pct):
            return None
            
        amount = (self.cash * position_pct) / price
        cost = amount * price
        
        self.cash -= cost
        self.positions[symbol] = {
            'amount': amount,
            'entry_price': price,
            'entry_time': datetime.now().isoformat()
        }
        
        self.trade_history.append({
            'type': 'BUY',
            'symbol': symbol,
            'price': price,
            'amount': amount,
            'time': datetime.now().isoformat()
        })
        
        return True
    
    def sell(self, symbol, price):
        """Execute sell"""
        if symbol not in self.positions:
            return None
            
        pos = self.positions[symbol]
        proceeds = pos['amount'] * price
        pnl = proceeds - (pos['amount'] * pos['entry_price'])
        
        self.cash += proceeds
        del self.positions[symbol]
        
        self.trade_history.append({
            'type': 'SELL',
            'symbol': symbol,
            'price': price,
            'amount': pos['amount'],
            'pnl': pnl,
            'time': datetime.now().isoformat()
        })
        
        return pnl
    
    def get_stats(self):
        """Get portfolio stats"""
        total_trades = len(self.trade_history)
        if total_trades == 0:
            return {'trades': 0, 'win_rate': 0, 'total_pnl': 0}
        
        sells = [t for t in self.trade_history if t['type'] == 'SELL']
        wins = len([s for s in sells if s.get('pnl', 0) > 0])
        
        return {
            'trades': total_trades,
            'wins': wins,
            'losses': len(sells) - wins,
            'win_rate': wins / len(sells) * 100 if sells else 0,
            'total_pnl': sum(s.get('pnl', 0) for s in sells)
        }

class RiskManager:
    def __init__(self):
        self.max_position_pct = 0.1  # Max 10% per trade
        self.stop_loss_pct = 0.05  # 5% stop loss
        self.take_profit_pct = 0.15  # 15% take profit
        self.max_daily_loss_pct = 0.10  # 10% max daily loss
        self.max_open_positions = 3
        
    def should_enter(self, portfolio, signal_strength=1.0):
        """Determine if should enter trade"""
        if len(portfolio.positions) >= self.max_open_positions:
            return False, "Max positions reached"
        return True, "OK"
    
    def should_exit(self, symbol, entry_price, current_price):
        """Check exit conditions"""
        pnl_pct = (current_price - entry_price) / entry_price
        
        if pnl_pct <= -self.stop_loss_pct:
            return True, "Stop loss"
        if pnl_pct >= self.take_profit_pct:
            return True, "Take profit"
        return False, None
    
    def calculate_position_size(self, portfolio, price, confidence=1.0):
        """Calculate position size based on confidence"""
        base_size = portfolio.cash * self.max_position_pct
        adjusted = base_size * confidence
        return adjusted / price

if __name__ == '__main__':
    # Test
    pm = RiskManager()
    portfolio = Portfolio()
    
    print("Testing Portfolio Manager...")
    portfolio.buy('BTC', 50000)
    print(f"Cash: {portfolio.cash}")
    print(f"Positions: {portfolio.positions}")
    
    portfolio.sell('BTC', 55000)
    print(f"Cash: {portfolio.cash}")
    print(f"Stats: {portfolio.get_stats()}")
