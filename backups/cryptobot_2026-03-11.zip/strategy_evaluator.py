#!/usr/bin/env python3
"""
Strategy Evaluator - Tests multiple strategies and picks winners
"""
import sys
sys.path.append('/Users/m/.openclaw/workspace-cryptobot')

from strategies import create_strategy, backtest
from backtester import create_strategy as create, backtest_df
from exchange_client import load_historical_data
import pandas as pd

def evaluate_strategies(symbol='BTC', timeframe='1h', capital=10000):
    """Evaluate all strategies and return rankings"""
    
    # Load data
    data = load_historical_data(symbol, timeframe)
    if data is None:
        print("No data found")
        return []
    
    df = data.copy()
    
    # Define strategies to test
    strategies = [
        ('RSI Oversold', create('rsi', oversold=25, overbought=75)),
        ('RSI Standard', create('rsi', oversold=30, overbought=70)),
        ('EMA 5/20', create('ema_crossover', fast=5, slow=20)),
        ('EMA 10/30', create('ema_crossover', fast=10, slow=30)),
        ('EMA 20/50', create('ema_crossover', fast=20, slow=50)),
        ('MACD', create('macd')),
        ('VWAP', create('vwap')),
        ('Stochastic', create('stochastic')),
        ('Bollinger 20', create('bollinger', period=20)),
    ]
    
    results = []
    
    print(f"Evaluating {len(strategies)} strategies on {symbol}...")
    print("=" * 60)
    
    for name, strategy in strategies:
        try:
            result = backtest_df(df, strategy, initial_balance=capital)
            results.append({
                'name': name,
                'return_pct': result['return_pct'],
                'trades': result['trades'],
                'strategy': strategy,
                'result': result
            })
        except Exception as e:
            print(f"Error with {name}: {e}")
    
    # Sort by return
    results.sort(key=lambda x: x['return_pct'], reverse=True)
    
    # Print results
    print(f"\n{'Rank':<6}{'Strategy':<20}{'Return %':<12}{'Trades':<10}")
    print("-" * 60)
    
    for i, r in enumerate(results, 1):
        print(f"{i:<6}{r['name']:<20}{r['return_pct']:>+.2f}%     {r['trades']:<10}")
    
    return results

def run_tournament(symbols=['BTC', 'ETH', 'SOL'], capital=10000):
    """Run tournament across multiple symbols"""
    print("=" * 60)
    print("STRATEGY TOURNAMENT")
    print("=" * 60)
    
    all_results = []
    
    for symbol in symbols:
        print(f"\n>>> Testing {symbol}")
        results = evaluate_strategies(symbol, capital=capital)
        if results:
            all_results.append({
                'symbol': symbol,
                'winner': results[0]['name'],
                'return_pct': results[0]['return_pct']
            })
    
    print("\n" + "=" * 60)
    print("TOURNAMENT RESULTS")
    print("=" * 60)
    for r in all_results:
        print(f"{r['symbol']}: {r['winner']} ({r['return_pct']:+.2f}%)")

if __name__ == '__main__':
    run_tournament()
