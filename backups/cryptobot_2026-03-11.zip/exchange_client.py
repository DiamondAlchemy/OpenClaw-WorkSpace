#!/usr/bin/env python3
"""
CryptoStrategist - Exchange Client
Currently using historical data mode (no live connection)
"""
import pandas as pd
import os

DATA_DIR = '/Users/m/.openclaw/workspace-cryptobot/data/'

def load_historical_data(symbol='BTC', timeframe='1h'):
    """Load historical data from CSV"""
    filename = f"{DATA_DIR}{symbol}_{timeframe}.csv"
    if os.path.exists(filename):
        df = pd.read_csv(filename)
        return df
    return None

def save_ohlcv_to_csv(ohlcv_data, symbol='BTC', timeframe='1h'):
    """Save OHLCV data to CSV"""
    os.makedirs(DATA_DIR, exist_ok=True)
    df = pd.DataFrame(ohlcv_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    filename = f"{DATA_DIR}{symbol}_{timeframe}.csv"
    df.to_csv(filename, index=False)
    return filename

def generate_sample_data():
    """Generate sample data for testing"""
    import numpy as np
    
    np.random.seed(42)
    n = 500
    
    # Generate random walk price data
    returns = np.random.normal(0.001, 0.02, n)
    price = 50000
    prices = [price]
    for r in returns:
        price = price * (1 + r)
        prices.append(price)
    
    data = []
    for i, p in enumerate(prices):
        high = p * (1 + abs(np.random.normal(0, 0.01)))
        low = p * (1 - abs(np.random.normal(0, 0.01)))
        open_price = p * (1 + np.random.normal(0, 0.005))
        volume = np.random.uniform(100, 1000)
        data.append([i, open_price, high, low, p, volume])
    
    return data

if __name__ == '__main__':
    print("Generating sample data...")
    data = generate_sample_data()
    filename = save_ohlcv_to_csv(data, 'BTC', '1h')
    print(f"Saved to: {filename}")
    
    df = load_historical_data('BTC', '1h')
    print(f"Loaded {len(df)} rows")
    print(df.tail())
