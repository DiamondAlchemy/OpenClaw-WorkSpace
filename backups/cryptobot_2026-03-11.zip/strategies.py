#!/usr/bin/env python3
"""
Advanced Trading Strategies Library
"""
import pandas as pd
import numpy as np
from functools import reduce

# ===== INDICATORS =====

def calculate_rsi(prices, period=14):
    delta = prices.diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def calculate_ema(prices, period):
    return prices.ewm(span=period, adjust=False).mean()

def calculate_sma(prices, period):
    return prices.rolling(window=period).mean()

def calculate_vwap(high, low, close, volume):
    typical_price = (high + low + close) / 3
    return (typical_price * volume).cumsum() / volume.cumsum()

def calculate_macd(prices, fast=12, slow=26, signal=9):
    ema_fast = calculate_ema(prices, fast)
    ema_slow = calculate_ema(prices, slow)
    macd_line = ema_fast - ema_slow
    signal_line = calculate_ema(macd_line, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram

def calculate_stochastic(high, low, close, k_period=14, d_period=3):
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    k = 100 * (close - lowest_low) / (highest_high - lowest_low)
    d = k.rolling(window=d_period).mean()
    return k, d

def calculate_bollinger_bands(prices, period=20, std_dev=2):
    sma = calculate_sma(prices, period)
    std = prices.rolling(window=period).std()
    upper = sma + (std * std_dev)
    lower = sma - (std * std_dev)
    return upper, sma, lower

def calculate_atr(high, low, close, period=14):
    tr1 = high - low
    tr2 = abs(high - close.shift())
    tr3 = abs(low - close.shift())
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.rolling(window=period).mean()

# ===== STRATEGIES =====

class Strategy:
    def __init__(self, name, params=None):
        self.name = name
        self.params = params or {}
        
    def generate_signals(self, df):
        raise NotImplementedError

class RSIStrategy(Strategy):
    def __init__(self, oversold=30, overbought=70):
        super().__init__("RSI", {'oversold': oversold, 'overbought': overbought})
        
    def generate_signals(self, df):
        df = df.copy()
        df['rsi'] = calculate_rsi(df['close'])
        df['signal'] = 0
        df.loc[df['rsi'] < self.params['oversold'], 'signal'] = 1  # Buy
        df.loc[df['rsi'] > self.params['overbought'], 'signal'] = -1  # Sell
        return df

class EMACrossoverStrategy(Strategy):
    def __init__(self, fast=10, slow=30):
        super().__init__("EMA Crossover", {'fast': fast, 'slow': slow})
        
    def generate_signals(self, df):
        df = df.copy()
        df['ema_fast'] = calculate_ema(df['close'], self.params['fast'])
        df['ema_slow'] = calculate_ema(df['close'], self.params['slow'])
        df['signal'] = 0
        df.loc[df['ema_fast'] > df['ema_slow'], 'signal'] = 1
        df.loc[df['ema_fast'] < df['ema_slow'], 'signal'] = -1
        # Signal change
        df['prev_signal'] = df['signal'].shift(1)
        df.loc[df['signal'] == df['prev_signal'], 'signal'] = 0
        return df

class MACDStrategy(Strategy):
    def __init__(self, fast=12, slow=26, signal=9):
        super().__init__("MACD", {'fast': fast, 'slow': slow, 'signal': signal})
        
    def generate_signals(self, df):
        df = df.copy()
        df['macd'], df['signal_line'], df['histogram'] = calculate_macd(df['close'])
        df['signal'] = 0
        df.loc[df['histogram'] > 0, 'signal'] = 1
        df.loc[df['histogram'] < 0, 'signal'] = -1
        return df

class VWAPStrategy(Strategy):
    def __init__(self, lookback=20):
        super().__init__("VWAP", {'lookback': lookback})
        
    def generate_signals(self, df):
        df = df.copy()
        df['vwap'] = calculate_vwap(df['high'], df['low'], df['close'], df['volume'])
        df['price_vs_vwap'] = df['close'] - df['vwap']
        df['signal'] = 0
        df.loc[df['price_vs_vwap'] < 0, 'signal'] = 1  # Price below VWAP = buy
        df.loc[df['price_vs_vwap'] > 0, 'signal'] = -1
        return df

class StochasticStrategy(Strategy):
    def __init__(self, k_period=14, d_period=3, oversold=20, overbought=80):
        super().__init__("Stochastic", {'k_period': k_period, 'd_period': d_period})
        
    def generate_signals(self, df):
        df = df.copy()
        df['k'], df['d'] = calculate_stochastic(df['high'], df['low'], df['close'])
        df['signal'] = 0
        df.loc[df['k'] < 20, 'signal'] = 1
        df.loc[df['k'] > 80, 'signal'] = -1
        return df

class BollingerBounceStrategy(Strategy):
    def __init__(self, period=20, std_dev=2):
        super().__init__("Bollinger Bounce", {'period': period, 'std_dev': std_dev})
        
    def generate_signals(self, df):
        df = df.copy()
        df['upper'], df['middle'], df['lower'] = calculate_bollinger_bands(df['close'])
        df['signal'] = 0
        df.loc[df['close'] < df['lower'], 'signal'] = 1
        df.loc[df['close'] > df['upper'], 'signal'] = -1
        return df

class CompositeStrategy(Strategy):
    """Combines multiple strategies - needs consensus"""
    def __init__(self, strategies, min_consensus=2):
        super().__init__("Composite", {'strategies': [s.name for s in strategies], 'consensus': min_consensus})
        self.strategies = strategies
        
    def generate_signals(self, df):
        for strategy in self.strategies:
            df = strategy.generate_signals(df)
            df[f"signal_{strategy.name}"] = df['signal']
        
        signal_cols = [f"signal_{s.name}" for s in self.strategies]
        df['signal'] = df[signal_cols].sum(axis=1)
        df.loc[df['signal'] >= self.params['consensus'], 'signal'] = 1
        df.loc[df['signal'] <= -self.params['consensus'], 'signal'] = -1
        df.loc[(df['signal'] > -self.params['consensus']) & (df['signal'] < self.params['consensus']), 'signal'] = 0
        return df

# ===== BACKTESTER =====

def backtest(df, strategy, initial_balance=10000, position_size=0.1):
    """Run backtest on a strategy"""
    df = strategy.generate_signals(df)
    
    balance = initial_balance
    position = 0
    entry_price = 0
    trades = []
    
    for i in range(1, len(df)):
        row = df.iloc[i]
        prev_row = df.iloc[i-1]
        
        # Buy signal
        if row['signal'] == 1 and position == 0:
            position = (balance * position_size) / row['close']
            balance -= position * row['close']
            entry_price = row['close']
            trades.append({
                'type': 'BUY',
                'price': row['close'],
                'time': row.get('timestamp', i),
                'rsi': row.get('rsi', 0),
                'balance': balance
            })
        
        # Sell signal
        elif row['signal'] == -1 and position > 0:
            pnl = (row['close'] - entry_price) * position
            balance += position * row['close']
            trades.append({
                'type': 'SELL',
                'price': row['close'],
                'pnl': pnl,
                'time': row.get('timestamp', i),
                'balance': balance
            })
            position = 0
    
    # Close position at end
    if position > 0:
        final_price = df.iloc[-1]['close']
        balance += position * final_price
    
    return_pct = ((balance - initial_balance) / initial_balance) * 100
    
    return {
        'initial': initial_balance,
        'final': balance,
        'return_pct': return_pct,
        'trades': len(trades),
        'trades_log': trades
    }

# ===== STRATEGY FACTORY =====

STRATEGIES = {
    'rsi': RSIStrategy,
    'ema_crossover': EMACrossoverStrategy,
    'macd': MACDStrategy,
    'vwap': VWAPStrategy,
    'stochastic': StochasticStrategy,
    'bollinger': BollingerBounceStrategy,
}

def create_strategy(name, **params):
    if name in STRATEGIES:
        return STRATEGIES[name](**params)
    raise ValueError(f"Unknown strategy: {name}")
