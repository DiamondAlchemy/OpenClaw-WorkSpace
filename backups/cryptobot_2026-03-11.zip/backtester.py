#!/usr/bin/env python3
"""
Backtesting engine - Fixed version
"""
import pandas as pd
import numpy as np

def prepare_data(df):
    """Ensure proper data format"""
    if isinstance(df, pd.DataFrame):
        # Already a DataFrame, ensure columns exist
        required = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        if not all(c in df.columns for c in required):
            # Try to map columns
            col_map = {
                'timestamp': ['timestamp', 'time', 'date', 'datetime'],
                'open': ['open', 'open_price'],
                'high': ['high', 'high_price'],
                'low': ['low', 'low_price'],
                'close': ['close', 'close_price'],
                'volume': ['volume', 'vol', 'volumne']
            }
            for req, alts in col_map.items():
                if req not in df.columns:
                    for alt in alts:
                        if alt in df.columns:
                            df[req] = df[alt]
                            break
        return df
    return None

# ===== INDICATORS =====

def calculate_rsi(prices, period=14):
    delta = prices.diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def calculate_ema(prices, period):
    return prices.ewm(span=period, adjust=False).mean()

def calculate_sma(prices, period):
    return prices.rolling(window=period).mean()

def calculate_vwap(high, low, close, volume):
    typical_price = (high + low + close) / 3
    return (typical_price * volume).cumsum() / volume.cumsum()

def calculate_macd(prices, fast=12, slow=26, signal=9):
    ema_fast = calculate_ema(prices, fast)
    ema_slow = calculate_ema(prices, slow)
    macd_line = ema_fast - ema_slow
    signal_line = calculate_ema(macd_line, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram

def calculate_stochastic(high, low, close, k_period=14, d_period=3):
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    k = 100 * (close - lowest_low) / (highest_high - lowest_low)
    d = k.rolling(window=d_period).mean()
    return k, d

def calculate_bollinger_bands(prices, period=20, std_dev=2):
    sma = calculate_sma(prices, period)
    std = prices.rolling(window=period).std()
    upper = sma + (std * std_dev)
    lower = sma - (std * std_dev)
    return upper, sma, lower

# ===== STRATEGIES =====

class Strategy:
    def __init__(self, name, params=None):
        self.name = name
        self.params = params or {}
        
    def generate_signals(self, df):
        raise NotImplementedError

class RSIStrategy(Strategy):
    def __init__(self, oversold=30, overbought=70):
        super().__init__("RSI", {'oversold': oversold, 'overbought': overbought})
        
    def generate_signals(self, df):
        df = df.copy()
        df['rsi'] = calculate_rsi(df['close'])
        df['signal'] = 0
        df.loc[df['rsi'] < self.params['oversold'], 'signal'] = 1
        df.loc[df['rsi'] > self.params['overbought'], 'signal'] = -1
        return df

class EMACrossoverStrategy(Strategy):
    def __init__(self, fast=10, slow=30):
        super().__init__("EMA Crossover", {'fast': fast, 'slow': slow})
        
    def generate_signals(self, df):
        df = df.copy()
        df['ema_fast'] = calculate_ema(df['close'], self.params['fast'])
        df['ema_slow'] = calculate_ema(df['close'], self.params['slow'])
        
        # Generate crossover signals
        df['signal'] = 0
        df['prev_fast'] = df['ema_fast'].shift(1)
        df['prev_slow'] = df['ema_slow'].shift(1)
        
        # Golden cross (buy)
        buy_cond = (df['prev_fast'] <= df['prev_slow']) & (df['ema_fast'] > df['ema_slow'])
        # Death cross (sell)
        sell_cond = (df['prev_fast'] >= df['prev_slow']) & (df['ema_fast'] < df['ema_slow'])
        
        df.loc[buy_cond, 'signal'] = 1
        df.loc[sell_cond, 'signal'] = -1
        
        return df

class MACDStrategy(Strategy):
    def __init__(self):
        super().__init__("MACD", {})
        
    def generate_signals(self, df):
        df = df.copy()
        df['macd'], df['signal_line'], df['histogram'] = calculate_macd(df['close'])
        df['signal'] = 0
        df.loc[df['histogram'] > 0, 'signal'] = 1
        df.loc[df['histogram'] < 0, 'signal'] = -1
        return df

class VWAPStrategy(Strategy):
    def __init__(self):
        super().__init__("VWAP", {})
        
    def generate_signals(self, df):
        df = df.copy()
        df['vwap'] = calculate_vwap(df['high'], df['low'], df['close'], df['volume'])
        df['signal'] = 0
        df.loc[df['close'] < df['vwap'], 'signal'] = 1
        df.loc[df['close'] > df['vwap'], 'signal'] = -1
        return df

class StochasticStrategy(Strategy):
    def __init__(self):
        super().__init__("Stochastic", {})
        
    def generate_signals(self, df):
        df = df.copy()
        df['k'], df['d'] = calculate_stochastic(df['high'], df['low'], df['close'])
        df['signal'] = 0
        df.loc[df['k'] < 20, 'signal'] = 1
        df.loc[df['k'] > 80, 'signal'] = -1
        return df

class BollingerStrategy(Strategy):
    def __init__(self, period=20):
        super().__init__("Bollinger", {'period': period})
        
    def generate_signals(self, df):
        df = df.copy()
        df['upper'], df['middle'], df['lower'] = calculate_bollinger_bands(df['close'], self.params['period'])
        df['signal'] = 0
        df.loc[df['close'] < df['lower'], 'signal'] = 1
        df.loc[df['close'] > df['upper'], 'signal'] = -1
        return df

# ===== BACKTEST FUNCTION =====

def backtest_df(df, strategy, initial_balance=10000, position_size=0.1):
    """Run backtest on DataFrame"""
    df = strategy.generate_signals(df)
    
    balance = initial_balance
    position = 0
    entry_price = 0
    trades = []
    
    for i in range(1, len(df)):
        row = df.iloc[i]
        
        # Buy signal
        if row['signal'] == 1 and position == 0:
            position = (balance * position_size) / row['close']
            balance -= position * row['close']
            entry_price = row['close']
            trades.append({'type': 'BUY', 'price': row['close'], 'balance': balance})
        
        # Sell signal
        elif row['signal'] == -1 and position > 0:
            pnl = (row['close'] - entry_price) * position
            balance += position * row['close']
            trades.append({'type': 'SELL', 'price': row['close'], 'pnl': pnl, 'balance': balance})
            position = 0
    
    # Close final position
    if position > 0:
        balance += position * df.iloc[-1]['close']
    
    return_pct = ((balance - initial_balance) / initial_balance) * 100
    
    return {
        'initial': initial_balance,
        'final': balance,
        'return_pct': return_pct,
        'trades': len(trades),
        'trades_log': trades
    }

# ===== STRATEGY FACTORY =====

def create_strategy(name, **params):
    strategies = {
        'rsi': RSIStrategy,
        'ema_crossover': EMACrossoverStrategy,
        'macd': MACDStrategy,
        'vwap': VWAPStrategy,
        'stochastic': StochasticStrategy,
        'bollinger': BollingerStrategy,
    }
    if name in strategies:
        return strategies[name](**params)
    raise ValueError(f"Unknown strategy: {name}")
