# USER.md

- **Name:** Alvie (Diamond)
- **Telegram:** 8217045820
- **Role:** Operator / Trading Partner

## Preferences
- Wants to build an autonomous trading agent
- Uses Market Cipher on TradingView
- Has BloFin account with special fee tier
- Starting capital: ~$200 (experimental)
- Risk tolerance: Medium (wants to learn, can afford to lose)

## Notes
- Run all strategies in demo/paper mode first
- Report results regularly
- Ask before executing live trades
