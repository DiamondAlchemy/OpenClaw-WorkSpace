#!/usr/bin/env python3
"""
BloFin connection and trading functions
"""
import ccxt
import os

# Demo mode by default
DEMO_MODE = True

def get_blofin(testnet=True):
    """Initialize BloFin exchange"""
    if testnet:
        # BloFin testnet
        exchange = ccxt.blofin({
            'enableRateLimit': True,
            'options': {'defaultType': 'swap'},
        })
        # Set testnet URL
        exchange.urls['api'] = {
            'public': 'https://api.blofin.com/api/v1',
            'private': 'https://api.blofin.com/api/v1',
        }
    else:
        exchange = ccxt.blofin({
            'enableRateLimit': True,
            'options': {'defaultType': 'swap'},
        })
    return exchange

def fetch_ohlcv(symbol='BTC/USDT:USDT', timeframe='1h', limit=100):
    """Fetch candlestick data"""
    exchange = get_blofin(testnet=DEMO_MODE)
    try:
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
        return ohlcv
    except Exception as e:
        print(f"Error fetching data: {e}")
        return None

def get_balance():
    """Get account balance"""
    exchange = get_blofin(testnet=DEMO_MODE)
    try:
        balance = exchange.fetch_balance()
        return balance
    except Exception as e:
        print(f"Error fetching balance: {e}")
        return None

def place_order(symbol, side, amount, price=None):
    """Place an order"""
    exchange = get_blofin(testnet=DEMO_MODE)
    try:
        order = exchange.create_order(
            symbol=symbol,
            type='market',
            side=side,
            amount=amount,
            price=price
        )
        return order
    except Exception as e:
        print(f"Error placing order: {e}")
        return None

if __name__ == '__main__':
    print("Testing BloFin connection...")
    balance = get_balance()
    if balance:
        print(f"Balance: {balance['total']}")
    else:
        print("Could not fetch balance")
